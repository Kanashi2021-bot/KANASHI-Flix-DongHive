package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.InitialData
import com.example.model.UserProfile
import com.example.model.VipPlan
import com.example.ui.theme.BloodDeep
import com.example.ui.theme.BloodPrimary
import com.example.ui.theme.BloodPrimaryDark
import com.example.ui.theme.BloodSurface
import com.example.ui.theme.BloodSurfaceElevated
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.QiGold
import com.example.ui.theme.SpiritJade
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import java.text.NumberFormat
import java.util.Locale

@Composable
fun VipScreen(
    user: UserProfile,
    onPlanSelect: (VipPlan) -> Unit,
    modifier: Modifier = Modifier
) {
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
        maximumFractionDigits = 0
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // VIP Header Banner
        item {
            Surface(
                color = BloodSurfaceElevated,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        Brush.linearGradient(listOf(QiGold, BloodPrimary)),
                        RoundedCornerShape(16.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(QiGold.copy(alpha = 0.2f))
                                .border(1.dp, QiGold, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "KANASHI VIP REALM",
                                color = QiGold,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.Diamond,
                            contentDescription = null,
                            tint = QiGold,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Keuntungan Status Murid VIP",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = CinzelFontFamily,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Tingkatkan kedudukanmu di dalam sekte. Dapatkan jalur penyerapan Qi tercepat tanpa gangguan rintangan duniawi.",
                        color = TextMuted,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Perks Grid
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        VipPerkItem(
                            icon = Icons.Default.VisibilityOff,
                            title = "Bebas Iklan Sepenuhnya",
                            desc = "Nonton terus tanpa jeda jeda iklan kultivasi per 4 episode"
                        )
                        VipPerkItem(
                            icon = Icons.Default.Verified,
                            title = "Lencana Centang Hijau Verified (✔)",
                            desc = "Tampil berwibawa di setiap kolom komentar episode"
                        )
                        VipPerkItem(
                            icon = Icons.Default.Speed,
                            title = "Kultivasi Cepat (2x EXP)",
                            desc = "Naikkan Level & Pangkat Ranah Sekte 2x Lebih Cepat"
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Current status card
                    Surface(
                        color = if (user.isVip) SpiritJade.copy(alpha = 0.15f) else BloodDeep,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (user.isVip) SpiritJade else BloodPrimaryDark,
                                RoundedCornerShape(10.dp)
                            )
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (user.isVip) Icons.Default.CheckCircle else Icons.Default.Diamond,
                                contentDescription = null,
                                tint = if (user.isVip) SpiritJade else QiGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (user.isVip) "STATUS: ANGGOTA VIP AKTIF" else "STATUS: PENGGUNA BIASA",
                                    color = if (user.isVip) SpiritJade else QiGold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (user.isVip) {
                                        "Masa aktif tersisa: ${user.vipDaysRemaining} hari (2x EXP + Bebas Iklan)"
                                    } else {
                                        "Pilih salah satu paket di bawah untuk mengaktifkan VIP"
                                    },
                                    color = TextPrimary.copy(alpha = 0.85f),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Plans Header
        item {
            Text(
                text = "Pilihan Paket Kultivasi VIP",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Plans List
        items(InitialData.VIP_PLANS, key = { it.id }) { plan ->
            Surface(
                color = BloodSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = if (plan.isFeatured) 1.5.dp else 1.dp,
                        color = if (plan.isFeatured) QiGold else Color(0x20FFFFFF),
                        shape = RoundedCornerShape(14.dp)
                    )
                    .testTag("plan_card_${plan.id}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = plan.name,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )

                        if (plan.isFeatured) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(QiGold)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "PALING POPULER",
                                    color = Color.Black,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = rupiahFormat.format(plan.price),
                        color = QiGold,
                        fontFamily = CinzelFontFamily,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = plan.description,
                        color = TextMuted,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { onPlanSelect(plan) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (plan.isFeatured) QiGold else BloodPrimary,
                            contentColor = if (plan.isFeatured) Color.Black else Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("buy_plan_${plan.id}")
                    ) {
                        Text(
                            text = "Beli Paket VIP",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VipPerkItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String
) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = QiGold,
            modifier = Modifier
                .size(16.dp)
                .padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = desc,
                color = TextMuted,
                fontSize = 10.sp
            )
        }
    }
}
