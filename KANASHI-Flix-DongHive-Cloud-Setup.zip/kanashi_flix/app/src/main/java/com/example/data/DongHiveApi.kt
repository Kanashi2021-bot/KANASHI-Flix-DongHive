package com.example.data

import com.example.model.AnimeTitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * DongHive API client. Ganti BASE_URL setelah backend Node.js dipasang di hosting HTTPS.
 * Contoh: https://kanashi-donghive-api.example.com
 */
object DongHiveApi {
    private const val BASE_URL = "https://GANTI-DENGAN-DOMAIN-BACKEND-ANDA"
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(120, TimeUnit.SECONDS)
        .build()

    suspend fun fetchCatalog(): List<AnimeTitle> = withContext(Dispatchers.IO) {
        require(!BASE_URL.contains("GANTI-DENGAN")) { "BASE_URL DongHive belum dikonfigurasi" }
        val request = Request.Builder()
            .url("${BASE_URL.trimEnd('/')}/api/catalog?pages=2&details=1&limit=20")
            .header("Accept", "application/json")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Backend DongHive HTTP ${response.code}")
            val json = JSONObject(response.body?.string().orEmpty())
            val items = json.optJSONArray("items") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until items.length()) {
                    val item = items.optJSONObject(i) ?: continue
                    val title = item.optString("title").trim()
                    val sourceUrl = item.optString("url").takeIf { it.startsWith("https://donghive.vip/") }
                    if (title.isBlank() || sourceUrl == null) continue
                    val episodes = item.optJSONArray("episodes")
                    val urls = linkedMapOf<Int, String>()
                    if (episodes != null) {
                        for (j in 0 until episodes.length()) {
                            val ep = episodes.optJSONObject(j) ?: continue
                            val epUrl = ep.optString("url")
                            val num = ep.optInt("number", -1)
                            if (num > 0 && epUrl.startsWith("https://donghive.vip/")) urls[num] = epUrl
                        }
                    }
                    val genres = item.optJSONArray("genres")
                    val genre = if (genres != null && genres.length() > 0) genres.optString(0) else "Action"
                    val statusRaw = item.optString("status", "Ongoing")
                    add(
                        AnimeTitle(
                            id = 10000 + i,
                            title = title,
                            type = "Donghua",
                            genre = genre.ifBlank { "Action" },
                            status = if (statusRaw.contains("complete", true) || statusRaw.contains("selesai", true)) "Selesai" else "Ongoing",
                            symbol = title.firstOrNull()?.toString() ?: "影",
                            glowColor = "#7E1526",
                            rating = "9.0",
                            totalEpisodes = maxOf(item.optInt("totalEpisodes", 0), urls.size, 1),
                            synopsis = item.optString("synopsis", "Sinopsis belum tersedia."),
                            videoUrls = urls,
                            releaseYear = "—",
                            studio = item.optString("network", "DongHive"),
                            posterUrl = item.optString("poster").takeIf { it.startsWith("http") },
                            sourceUrl = sourceUrl
                        )
                    )
                }
            }
        }
    }
}
