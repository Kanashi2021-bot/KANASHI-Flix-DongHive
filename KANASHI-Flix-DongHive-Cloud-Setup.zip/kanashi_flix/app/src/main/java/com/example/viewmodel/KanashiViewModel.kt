package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CultivationRanks
import com.example.data.KanashiRepository
import com.example.data.parseVideoUrlsText
import com.example.model.AnimeTitle
import com.example.model.EpisodeComment
import com.example.model.ScreenTab
import com.example.model.SectAnnouncement
import com.example.model.UserProfile
import com.example.model.VipPlan
import com.example.model.WatchHistoryItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class KanashiViewModel(application: Application) : AndroidViewModel(application) {

    val repository = KanashiRepository(application)

    init {
        viewModelScope.launch { repository.refreshDongHiveCatalog() }
    }

    val userProfile: StateFlow<UserProfile> = repository.userProfile
    val titles: StateFlow<List<AnimeTitle>> = repository.titles
    val favorites: StateFlow<Set<Int>> = repository.favorites
    val history: StateFlow<List<WatchHistoryItem>> = repository.history
    val comments: StateFlow<List<EpisodeComment>> = repository.comments
    val announcements: StateFlow<List<SectAnnouncement>> = repository.announcements
    val isAdmin: StateFlow<Boolean> = repository.isAdmin

    private val _currentTab = MutableStateFlow(ScreenTab.HOME)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    private val _activeWatchTitle = MutableStateFlow<AnimeTitle?>(null)
    val activeWatchTitle: StateFlow<AnimeTitle?> = _activeWatchTitle.asStateFlow()

    private val _activeWatchEpisode = MutableStateFlow(1)
    val activeWatchEpisode: StateFlow<Int> = _activeWatchEpisode.asStateFlow()

    private val _detailModalTitle = MutableStateFlow<AnimeTitle?>(null)
    val detailModalTitle: StateFlow<AnimeTitle?> = _detailModalTitle.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Semua")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedGenre = MutableStateFlow("Semua")
    val selectedGenre: StateFlow<String> = _selectedGenre.asStateFlow()

    private val _selectedStatus = MutableStateFlow("Semua")
    val selectedStatus: StateFlow<String> = _selectedStatus.asStateFlow()

    private val _selectedSort = MutableStateFlow("Rating Tertinggi")
    val selectedSort: StateFlow<String> = _selectedSort.asStateFlow()

    // Modals
    private val _showPaymentDialog = MutableStateFlow<VipPlan?>(null)
    val showPaymentDialog: StateFlow<VipPlan?> = _showPaymentDialog.asStateFlow()

    private val _showAvatarDialog = MutableStateFlow(false)
    val showAvatarDialog: StateFlow<Boolean> = _showAvatarDialog.asStateFlow()

    private val _showAdminDialog = MutableStateFlow(false)
    val showAdminDialog: StateFlow<Boolean> = _showAdminDialog.asStateFlow()

    private val _showMeditationDialog = MutableStateFlow(false)
    val showMeditationDialog: StateFlow<Boolean> = _showMeditationDialog.asStateFlow()

    private val _showAdModal = MutableStateFlow(false)
    val showAdModal: StateFlow<Boolean> = _showAdModal.asStateFlow()

    private val _pendingEpisode = MutableStateFlow<Int?>(null)

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _levelUpCelebration = MutableStateFlow<String?>(null)
    val levelUpCelebration: StateFlow<String?> = _levelUpCelebration.asStateFlow()

    data class CatalogFilter(
        val query: String = "",
        val category: String = "Semua",
        val genre: String = "Semua",
        val status: String = "Semua",
        val sort: String = "Rating Tertinggi"
    )

    private val _filterState = MutableStateFlow(CatalogFilter())

    // Filtered Titles
    val filteredTitles: StateFlow<List<AnimeTitle>> = combine(
        titles,
        _filterState
    ) { allTitles, filter ->
        var list = allTitles

        if (filter.query.isNotBlank()) {
            list = list.filter {
                it.title.contains(filter.query, ignoreCase = true) ||
                        it.genre.contains(filter.query, ignoreCase = true) ||
                        it.type.contains(filter.query, ignoreCase = true)
            }
        }

        if (filter.category != "Semua") {
            list = list.filter { it.type.equals(filter.category, ignoreCase = true) }
        }

        if (filter.genre != "Semua") {
            list = list.filter { it.genre.equals(filter.genre, ignoreCase = true) }
        }

        if (filter.status != "Semua") {
            list = list.filter { it.status.equals(filter.status, ignoreCase = true) }
        }

        when (filter.sort) {
            "Rating Tertinggi" -> list.sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }
            "Paling Populer" -> list.sortedByDescending { it.totalEpisodes }
            "Terbaru" -> list.sortedByDescending { it.id }
            else -> list
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(tab: ScreenTab) {
        _currentTab.value = tab
    }

    fun openDetail(title: AnimeTitle) {
        _detailModalTitle.value = title
    }

    fun closeDetail() {
        _detailModalTitle.value = null
    }

    fun openWatch(title: AnimeTitle, episode: Int = 1) {
        val user = userProfile.value
        val watchedCount = repository.watchedEpisodesCount.value
        // If not VIP and not Admin, show ad every 4 episodes
        if (!user.isVip && !isAdmin.value && (watchedCount + 1) % 4 == 0) {
            _pendingEpisode.value = episode
            _activeWatchTitle.value = title
            _showAdModal.value = true
            return
        }

        startWatching(title, episode)
    }

    fun skipAdAndContinue() {
        _showAdModal.value = false
        val ep = _pendingEpisode.value ?: 1
        _pendingEpisode.value = null
        val title = _activeWatchTitle.value
        if (title != null) {
            startWatching(title, ep)
        }
    }

    private fun startWatching(title: AnimeTitle, episode: Int) {
        _detailModalTitle.value = null
        _activeWatchTitle.value = title
        _activeWatchEpisode.value = episode
        repository.recordEpisodeWatched(title.id, episode, title.title, title.symbol, title.type)
        showToast("Membuka Episode $episode • +${if (userProfile.value.isVip) 30 else 15} EXP Kultivasi")
    }

    fun closeWatch() {
        _activeWatchTitle.value = null
    }

    fun changeEpisode(episode: Int) {
        val title = _activeWatchTitle.value ?: return
        openWatch(title, episode)
    }

    fun toggleFavorite(titleId: Int) {
        val added = repository.toggleFavorite(titleId)
        showToast(if (added) "Ditambahkan ke Favorit Sekte ♥" else "Dihapus dari Favorit")
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        _filterState.value = _filterState.value.copy(query = query)
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
        _filterState.value = _filterState.value.copy(category = category)
    }

    fun setGenre(genre: String) {
        _selectedGenre.value = genre
        _filterState.value = _filterState.value.copy(genre = genre)
    }

    fun setStatus(status: String) {
        _selectedStatus.value = status
        _filterState.value = _filterState.value.copy(status = status)
    }

    fun setSort(sort: String) {
        _selectedSort.value = sort
        _filterState.value = _filterState.value.copy(sort = sort)
    }

    fun openPayment(plan: VipPlan) {
        _showPaymentDialog.value = plan
    }

    fun closePayment() {
        _showPaymentDialog.value = null
    }

    fun confirmPayment(plan: VipPlan) {
        repository.activateVip(plan.days, plan.expBonus)
        _showPaymentDialog.value = null
        _levelUpCelebration.value = "Selamat! Status ${plan.name} Telah Aktif! +${plan.expBonus} EXP"
        showToast("Pembayaran Berhasil! Anda kini Murid VIP.")
    }

    fun openAvatarModal() {
        _showAvatarDialog.value = true
    }

    fun closeAvatarModal() {
        _showAvatarDialog.value = false
    }

    fun selectAvatar(symbol: String, color: String) {
        val updated = userProfile.value.copy(
            avatarSymbol = symbol,
            avatarColorHex = color
        )
        repository.saveUserProfile(updated)
        _showAvatarDialog.value = false
        showToast("Segel Avatar berhasil diperbarui: $symbol")
    }

    fun updateProfile(name: String, sect: String) {
        val updated = userProfile.value.copy(
            name = name.ifBlank { userProfile.value.name },
            sect = sect.ifBlank { userProfile.value.sect }
        )
        repository.saveUserProfile(updated)
        showToast("Profil Sekte berhasil diperbarui")
    }

    fun openMeditation() {
        _showMeditationDialog.value = true
    }

    fun closeMeditation() {
        _showMeditationDialog.value = false
    }

    fun executeMeditation() {
        val result = repository.performDailyMeditation()
        if (result.first) {
            _levelUpCelebration.value = "Meditasi Selesai! Menyerap Qi Alam Langit +${result.second} EXP"
        } else {
            showToast("Anda sudah bermeditasi hari ini. Silakan kembali besok!")
        }
    }

    fun openAdmin() {
        _showAdminDialog.value = true
    }

    fun closeAdmin() {
        _showAdminDialog.value = false
    }

    fun loginAdmin(code: String): Boolean {
        val success = repository.verifyAdmin(code)
        if (success) {
            showToast("Gerbang Tetua Terbuka: Mode Admin Aktif")
        } else {
            showToast("Kunci Sandi Salah!")
        }
        return success
    }

    fun logoutAdmin() {
        repository.revokeAdmin()
        showToast("Mode Admin Dinonaktifkan")
    }

    fun addCustomAnime(
        title: String,
        type: String,
        genre: String,
        status: String,
        symbol: String,
        episodes: Int,
        synopsis: String,
        videoUrlsText: String = ""
    ) {
        val newId = (System.currentTimeMillis() % 100000).toInt() + 100
        val anime = AnimeTitle(
            id = newId,
            title = title,
            type = type,
            genre = genre,
            status = status,
            symbol = symbol.ifBlank { "影" },
            glowColor = "#8F0C20",
            rating = "9.0",
            totalEpisodes = episodes,
            synopsis = synopsis.ifBlank { "Judul baru ditambahkan oleh Tetua Sekte KANASHI-FLIX." },
            releaseYear = "2026",
            studio = "Sekte Produksi Kanashi",
            videoUrls = parseVideoUrlsText(videoUrlsText)
        )
        repository.addCustomTitle(anime)
        showToast("Judul berhasil ditambahkan ke Katalog: $title")
    }

    /** Atur ulang URL video asli per-episode untuk judul yang sudah ada. */
    fun setTitleVideoUrls(titleId: Int, videoUrlsText: String) {
        val map = parseVideoUrlsText(videoUrlsText)
        repository.setTitleVideoUrls(titleId, map)
        showToast(
            if (map.isEmpty()) "Semua URL video untuk judul ini dihapus"
            else "${map.size} sumber video asli berhasil disimpan"
        )
    }

    fun postAnnouncement(title: String, content: String, tag: String) {
        repository.postAnnouncement(title, content, tag)
        showToast("Pengumuman Sekte berhasil diterbitkan!")
    }

    fun boostExp(amount: Int) {
        repository.addExp(amount)
        val rank = CultivationRanks.getRankTitle(userProfile.value.level)
        _levelUpCelebration.value = "Terobosan Ranah Sukses! Ranah saat ini: $rank (Lv ${userProfile.value.level})"
    }

    fun clearHistory() {
        repository.clearHistory()
        showToast("Riwayat Nonton telah dibersihkan")
    }

    fun postComment(titleId: Int, episode: Int, text: String) {
        if (text.isBlank()) return
        repository.addComment(titleId, episode, text)
        showToast("Komentar terkirim! +5 EXP Kultivasi")
    }

    fun toggleCommentLike(commentId: String) {
        repository.toggleCommentLike(commentId)
    }

    fun showToast(message: String) {
        _toastMessage.value = message
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun clearCelebration() {
        _levelUpCelebration.value = null
    }
}
