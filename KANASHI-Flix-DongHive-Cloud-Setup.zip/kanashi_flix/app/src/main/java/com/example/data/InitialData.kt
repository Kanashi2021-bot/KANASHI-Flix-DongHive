package com.example.data

import com.example.model.AnimeTitle
import com.example.model.EpisodeComment
import com.example.model.SectAnnouncement
import com.example.model.VipPlan

object CultivationRanks {
    val RANKS = listOf(
        "Qi Condensation",         // Lv 1 - 100
        "Foundation Establishment", // Lv 101 - 200
        "Core Formation",           // Lv 201 - 300
        "Nascent Soul",             // Lv 301 - 400
        "Deity Transformation",     // Lv 401 - 500
        "Void Refinement",          // Lv 501 - 600
        "Mahayana",                 // Lv 601 - 700
        "Heavenly Emperor",         // Lv 701 - 800
        "Penguasa Tertinggi"        // Lv 801+
    )

    fun getRankTitle(level: Int): String {
        val index = ((level - 1) / 100).coerceIn(0, RANKS.size - 1)
        return RANKS[index]
    }

    val SECTS = listOf(
        "Sekte Pedang Darah",
        "Sekte Langit Misterius",
        "Lembah Iblis Abadi",
        "Istana Teratai Hitam"
    )

    val AVATAR_SEALS = listOf(
        "影" to "#E11D35", // Shadow - Crimson
        "炎" to "#FF5722", // Flame - Orange
        "龍" to "#D6B477", // Dragon - Gold
        "劍" to "#4FC3F7", // Sword - Cyan
        "魔" to "#9C27B0", // Demon - Purple
        "凰" to "#E91E63", // Phoenix - Pink
        "魂" to "#00BFA5", // Soul - Teal
        "仙" to "#FFD700"  // Immortal - Yellow
    )
}

object InitialData {

    val VIP_PLANS = listOf(
        VipPlan(
            id = 1,
            name = "1 Bulan VIP",
            price = 10000,
            days = 30,
            expBonus = 200,
            isFeatured = false,
            description = "Bebas Iklan 30 Hari + Centang Hijau Verified + Bonus 200 EXP"
        ),
        VipPlan(
            id = 2,
            name = "2 Bulan VIP",
            price = 20000,
            days = 60,
            expBonus = 450,
            isFeatured = false,
            description = "Bebas Iklan 60 Hari + Centang Hijau Verified + Bonus 450 EXP"
        ),
        VipPlan(
            id = 3,
            name = "3 Bulan VIP",
            price = 30000,
            days = 90,
            expBonus = 750,
            isFeatured = false,
            description = "Bebas Iklan 90 Hari + Centang Hijau Verified + Bonus 750 EXP"
        ),
        VipPlan(
            id = 4,
            name = "6 Bulan VIP",
            price = 50000,
            days = 180,
            expBonus = 1600,
            isFeatured = true,
            description = "Bebas Iklan 180 Hari + Prioritas Server 4K + Bonus 1.600 EXP [PALING POPULER]"
        ),
        VipPlan(
            id = 5,
            name = "1 Tahun VIP",
            price = 100000,
            days = 365,
            expBonus = 3500,
            isFeatured = false,
            description = "Akses Penuh Tanpa Batas 1 Tahun + Gelar Tetua Sekte Abadi + Bonus 3.500 EXP"
        )
    )

    val SECT_ANNOUNCEMENTS = listOf(
        SectAnnouncement(
            id = "ann_1",
            title = "🔥 Server Pembaruan Realm v2.5: KANASHI-FLIX Android",
            content = "Selamat datang para kultivator! Aplikasi resmi KANASHI-FLIX kini hadir dengan kinerja secepat kilat petir dewa, tanpa gangguan lag, pemutar video interaktif, dan sistem kultivasi terintegrasi.",
            date = "14 Okt 2026",
            tag = "UPDATE"
        ),
        SectAnnouncement(
            id = "ann_2",
            title = "⚡ Event Terobosan Ranah: 2x Cultivation EXP",
            content = "Seluruh anggota sekte yang menonton Donghua & Anime akan mendapatkan ganda kultivasi EXP! Segera tingkatkan ranah dari Qi Condensation menuju Core Formation dan Nascent Soul.",
            date = "13 Okt 2026",
            tag = "EVENT"
        ),
        SectAnnouncement(
            id = "ann_3",
            title = "👑 Rekomendasi Tetua: Battle Through the Heavens Season Baru",
            content = "Episode pertarungan Xiao Yan di Lembah Iblis kini telah dibuka. Saksikan teknik Heavenly Flame bertarung melawan Sekte Hall of Souls!",
            date = "12 Okt 2026",
            tag = "PENGUMUMAN"
        ),
        SectAnnouncement(
            id = "ann_4",
            title = "💎 Hak Istimewa VIP Realm: Bebas Iklan & Badge Eksklusif",
            content = "Anggota VIP kini dapat menikmati streaming tanpa jeda iklan, badge verifikasi centang hijau di kolom komentar, dan peningkatan EXP 2x lipat setiap episode.",
            date = "10 Okt 2026",
            tag = "VIP"
        )
    )

    val DEFAULT_TITLES = listOf(
        AnimeTitle(
            id = 1,
            title = "Battle Through the Heavens",
            type = "Donghua",
            genre = "Cultivation",
            status = "Ongoing",
            symbol = "炎",
            glowColor = "#7E1526",
            rating = "9.2",
            totalEpisodes = 104,
            synopsis = "Di tanah di mana sihir tidak ada melainkan kekuatan Dou Qi yang memerintah, Xiao Yan sang jenius tiba-tiba kehilangan seluruh kekuatannya. Setelah diremehkan oleh sekte tunangannya, ia menemukan jiwa master legendaris Yao Chen di dalam cincin pusaka ibunya dan bangkit memburu Heavenly Flame.",
            releaseYear = "2024",
            studio = "Motion Magic / Tencent Video"
            // URL video asli per episode diatur melalui Panel Admin > tab "Sumber Video"
            // (format: 1=https://...  2=https://...). Tidak lagi memakai video contoh.
        ),
        AnimeTitle(
            id = 2,
            title = "Renegade Immortal",
            type = "Donghua",
            genre = "Fantasy",
            status = "Ongoing",
            symbol = "仙",
            glowColor = "#5E1423",
            rating = "9.1",
            totalEpisodes = 52,
            synopsis = "Wang Lin adalah pemuda desa biasa yang ditolak oleh sekte abadi karena bakat spiritualnya yang rendah. Namun karena tekad baja dan manik langit misterius, ia melangkah di jalan kultivasi renegade yang kejam demi melindungi keluarganya dan menaklukkan hukum langit.",
            releaseYear = "2024",
            studio = "Sparkly Key Animation"
        ),
        AnimeTitle(
            id = 3,
            title = "Soul Land (Douluo Dalu)",
            type = "Donghua",
            genre = "Adventure",
            status = "Selesai",
            symbol = "魂",
            glowColor = "#1E4C4A",
            rating = "9.0",
            totalEpisodes = 250,
            synopsis = "Tang San bereinkarnasi ke Benua Douluo dengan membawa pengetahuan rahasia Sekte Tang. Di dunia di mana setiap orang membangkitkan Spirit bela diri, ia membangkitkan Rumput Biru Perak yang dianggap sampah namun memiliki kekuatan tersembunyi yang mengguncang dunia roh.",
            releaseYear = "2023",
            studio = "Sparkly Key Animation"
        ),
        AnimeTitle(
            id = 4,
            title = "Perfect World",
            type = "Donghua",
            genre = "Action",
            status = "Ongoing",
            symbol = "天",
            glowColor = "#9B2534",
            rating = "9.3",
            totalEpisodes = 160,
            synopsis = "Dilahirkan dalam dunia tak tertandingi di mana desa-desa berjuang demi bertahan hidup dari monster purba, Shi Hao sang anak jenius lahir dengan Tulang Tertinggi yang dicuri oleh kerabatnya sendiri. Dibesarkan di Desa Batu, ia bangkit mencari kebenaran dan menghancurkan langit.",
            releaseYear = "2024",
            studio = "Foch Film / Tencent Video"
        ),
        AnimeTitle(
            id = 5,
            title = "A Record of a Mortal's Journey",
            type = "Donghua",
            genre = "Cultivation",
            status = "Ongoing",
            symbol = "剑",
            glowColor = "#36584B",
            rating = "8.9",
            totalEpisodes = 96,
            synopsis = "Kisah realistis Han Li, seorang pemuda miskin dari desa kecil yang memasuki sekte bela diri biasa. Menghadapi konspirasi kejam, iblis licik, dan hukum rimba dunia kultivasi, kehati-hatian dan botol hijau misterius miliknya menjadi kunci bertahan hidup menuju keabadian.",
            releaseYear = "2024",
            studio = "Original Force / Bilibili"
        ),
        AnimeTitle(
            id = 6,
            title = "Demon Slayer: Kimetsu no Yaiba",
            type = "Anime",
            genre = "Action",
            status = "Selesai",
            symbol = "滅",
            glowColor = "#85202C",
            rating = "9.4",
            totalEpisodes = 55,
            synopsis = "Keluarga Tanjiro Kamado dibantai oleh iblis dan adik perempuannya, Nezuko, diubah menjadi iblis. Bertekad menyelamatkan adiknya dan membalaskan dendam keluarganya, Tanjiro bergabung dengan Korps Pembasmi Iblis untuk menghadapi Muzan Kibutsuji.",
            releaseYear = "2024",
            studio = "Ufotable"
        ),
        AnimeTitle(
            id = 7,
            title = "Solo Leveling",
            type = "Anime",
            genre = "Fantasy",
            status = "Ongoing",
            symbol = "影",
            glowColor = "#34233F",
            rating = "9.5",
            totalEpisodes = 24,
            synopsis = "Sung Jin-Woo dikenal sebagai Hunter terlemah di seluruh dunia (E-Rank). Saat terjebak dalam Double Dungeon maut dan di ambang kematian, ia terpilih oleh sistem misterius 'Player' yang memungkinkannya menaikkan level tanpa batas dan memanggil pasukan bayangan.",
            releaseYear = "2024",
            studio = "A-1 Pictures"
        ),
        AnimeTitle(
            id = 8,
            title = "Jujutsu Kaisen",
            type = "Anime",
            genre = "Action",
            status = "Ongoing",
            symbol = "呪",
            glowColor = "#57303C",
            rating = "9.1",
            totalEpisodes = 47,
            synopsis = "Yuji Itadori menelan jari terkutuk milik Raja Kutukan Sukuna demi menyelamatkan temannya. Di bawah bimbingan penyihir terkuat Satoru Gojo di SMA Jujutsu Tokyo, Yuji bertarung di garis depan melawan roh-roh kutukan yang mengancam umat manusia.",
            releaseYear = "2023",
            studio = "MAPPA"
        ),
        AnimeTitle(
            id = 9,
            title = "Swallowed Star",
            type = "Donghua",
            genre = "Action",
            status = "Ongoing",
            symbol = "星",
            glowColor = "#263238",
            rating = "9.3",
            totalEpisodes = 130,
            synopsis = "Bumi masa depan hancur oleh virus RR dan invasi monster bermutasi tinggi. Luo Feng bangkit dari pejuang seni bela diri menjadi pejuang spiritual terkuat yang melintasi alam semesta galaksi bintang.",
            releaseYear = "2024",
            studio = "Sparkly Key Animation / Tencent Video"
        ),
        AnimeTitle(
            id = 10,
            title = "Shrouding the Heavens",
            type = "Donghua",
            genre = "Cultivation",
            status = "Ongoing",
            symbol = "棺",
            glowColor = "#4A148C",
            rating = "9.0",
            totalEpisodes = 80,
            synopsis = "Sembilan naga raksasa menarik peti perunggu purba melintasi galaksi menuju Gunung Tai. Ye Fan dan teman-temannya terbawa ke dunia kultivasi antariksa kuno penuh misteri dan jalan menuju keabadian sejati.",
            releaseYear = "2024",
            studio = "Original Force / Tencent Video"
        ),
        AnimeTitle(
            id = 11,
            title = "Chainsaw Man",
            type = "Anime",
            genre = "Supernatural",
            status = "Selesai",
            symbol = "鋸",
            glowColor = "#BF360C",
            rating = "9.0",
            totalEpisodes = 12,
            synopsis = "Denji, pemuda miskin yang hidup bersama Pochita iblis gergaji mesin, dikhianati dan dibunuh oleh Yakuza. Pochita melebur dengan jantung Denji dan membangkitkannya kembali sebagai pembasmi iblis Chainsaw Man.",
            releaseYear = "2022",
            studio = "MAPPA"
        ),
        AnimeTitle(
            id = 12,
            title = "Bleach: Thousand-Year Blood War",
            type = "Anime",
            genre = "Action",
            status = "Ongoing",
            symbol = "死",
            glowColor = "#3E2723",
            rating = "9.4",
            totalEpisodes = 36,
            synopsis = "Perang suci seribu tahun antara Soul Society dan Kekaisaran Wandenreich Quincy pimpinan Yhwach pecah. Kurosaki Ichigo harus melampaui batas Zanpakuto miliknya untuk menyelamatkan dunia spiritual.",
            releaseYear = "2024",
            studio = "Pierrot Films"
        )
    )

    val INITIAL_COMMENTS = listOf(
        EpisodeComment(
            id = "c1",
            titleId = 1,
            episode = 1,
            authorName = "Master Pedang Li",
            authorRank = "Core Formation Lv 245",
            authorAvatar = "劍",
            isVip = true,
            content = "Animasi pertarungan api Xiao Yan luar biasa halus! Sekte Hall of Souls bakal kewalahan di episode berikutnya.",
            likes = 34,
            timestampFormatted = "10 menit lalu"
        ),
        EpisodeComment(
            id = "c2",
            titleId = 1,
            episode = 1,
            authorName = "Kultivator Awan Hitam",
            authorRank = "Foundation Establishment Lv 112",
            authorAvatar = "影",
            isVip = false,
            content = "Yao Chen guru terbaik di dunia kultivasi. Aura apinya beneran bikin merinding!",
            likes = 18,
            timestampFormatted = "1 jam lalu"
        ),
        EpisodeComment(
            id = "c3",
            titleId = 7,
            episode = 1,
            authorName = "Raja Bayangan Nocturne",
            authorRank = "Nascent Soul Lv 380",
            authorAvatar = "魔",
            isVip = true,
            content = "Arise! Adegan kebangkitan Jin-Woo tidak pernah mengecewakan. Kualitas streaming 1080p di KANASHI-FLIX mantap jiwa.",
            likes = 79,
            timestampFormatted = "3 jam lalu"
        ),
        EpisodeComment(
            id = "c4",
            titleId = 2,
            episode = 1,
            authorName = "Tetua Wang",
            authorRank = "Deity Transformation Lv 410",
            authorAvatar = "仙",
            isVip = true,
            content = "Renegade Immortal Donghua paling berdarah dan filosofis tahun ini. Jangan lewatkan episode 2!",
            likes = 45,
            timestampFormatted = "5 jam lalu"
        )
    )
}
