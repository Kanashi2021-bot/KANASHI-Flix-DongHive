# Integrasi DongHive untuk KANASHI-Flix

Integrasi ini menghubungkan aplikasi Android ke backend Node.js yang mengambil data publik dari DongHive. Aplikasi tetap memakai katalog lokal/anime yang sudah ada; hasil DongHive ditambahkan sebagai katalog Donghua saat backend berhasil diakses.

## Data yang diambil
- Poster dari `og:image` atau gambar kartu katalog.
- Nama judul, sinopsis, genre, status, dan jumlah episode.
- Daftar episode beserta URL halaman episode DongHive.
- URL embed video yang tercantum pada halaman episode (`/api/episode?url=...`).
- Pemutaran dilakukan lewat halaman episode/embed di WebView aplikasi. URL halaman bukan file `.m3u8` langsung; backend tidak mengekstrak manifest video bertanda tangan.

## 1. Jalankan backend
Butuh Node.js 18 atau lebih baru.

```bash
cd donghive-backend
npm install
npm start
```

Backend berjalan pada port `8787` secara default. Tes di browser:

- `http://localhost:8787/health`
- `http://localhost:8787/api/catalog?pages=1&details=0&limit=10`
- `http://localhost:8787/api/series?url=https%3A%2F%2Fdonghive.vip%2Fperfect-world%2F`

Catatan: `details=1` melakukan permintaan tambahan untuk tiap series sehingga lebih lambat. Backend membatasi jumlah halaman/hasil untuk mengurangi beban situs sumber.

## 2. Hubungkan aplikasi Android ke backend
Buka:
`app/src/main/java/com/example/data/DongHiveApi.kt`

Ganti konstanta `BASE_URL` dari placeholder menjadi URL HTTPS backend Anda, misalnya:

```kotlin
private const val BASE_URL = "https://domain-backend-anda.example"
```

Gunakan alamat backend yang benar-benar sudah di-deploy. `localhost` pada HP Android berarti HP itu sendiri, bukan komputer. Untuk uji emulator Android Studio, alamat lokal umumnya `http://10.0.2.2:8787`, tetapi gunakan HTTPS saat rilis dan sesuaikan konfigurasi cleartext jika hanya untuk tes lokal.

Aplikasi meminta `/api/catalog?pages=2&details=1&limit=20` saat dibuka. Jika backend belum dikonfigurasi atau gagal, katalog bawaan aplikasi tetap dipakai.

## 3. Endpoint API
- `GET /health`
- `GET /api/catalog?pages=2&details=1&limit=20`
- `GET /api/series?url=<URL_SERIES_DONGHIVE>`
- `GET /api/episode?url=<URL_EPISODE_DONGHIVE>`

Endpoint hanya menerima URL HTTPS dari `donghive.vip`/subdomain-nya untuk mengurangi risiko SSRF.

## Batasan penting
- Selector HTML dapat berubah bila DongHive mengubah desain situs; scraper mungkin perlu diperbarui.
- Tidak ada API resmi DongHive yang diasumsikan di sini; ini adalah pengambilan data halaman web dan bisa sewaktu-waktu berhenti bekerja atau dibatasi.
- Poster, halaman episode, dan embed bergantung pada ketersediaan serta kebijakan situs sumber. Backend tidak melewati login, DRM, geo-block, atau pembatasan pemutaran.
- Gunakan hanya konten yang memang boleh diakses/disematkan, dan patuhi syarat layanan serta hak cipta sumber.
