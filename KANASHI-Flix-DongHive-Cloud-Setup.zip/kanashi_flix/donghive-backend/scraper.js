import * as cheerio from 'cheerio';

const BASE = 'https://donghive.vip';
const TIMEOUT = 25000;
const RETRIES = 3;
const RETRYABLE = new Set([403, 408, 425, 429, 500, 502, 503, 504, 520, 522, 524]);
const UAS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
];
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const absolute = (url, base = BASE) => { try { return new URL(url || '', base).href; } catch { return null; } };
const isDongHiveUrl = value => {
  try { const u = new URL(value); return u.protocol === 'https:' && (u.hostname === 'donghive.vip' || u.hostname.endsWith('.donghive.vip')); }
  catch { return false; }
};

async function request(url, { referer = `${BASE}/` } = {}) {
  if (!isDongHiveUrl(url) && !url.startsWith('https://www.dailymotion.com/') && !url.startsWith('https://geo.dailymotion.com/')) {
    throw new Error('URL tidak diizinkan. Sumber hanya DongHive atau embed Dailymotion.');
  }
  let lastError;
  for (let attempt = 0; attempt <= RETRIES; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT);
    try {
      const response = await fetch(url, {
        headers: {
          Accept: 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
          'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
          'User-Agent': UAS[attempt % UAS.length], Referer: referer
        }, signal: controller.signal, redirect: 'follow'
      });
      const text = await response.text();
      if (RETRYABLE.has(response.status) && attempt < RETRIES) {
        const retryAfter = Number(response.headers.get('retry-after'));
        await sleep(retryAfter > 0 ? retryAfter * 1000 : Math.min(1000 * 2 ** attempt, 10000));
        continue;
      }
      if (!response.ok) throw new Error(`DongHive HTTP ${response.status}`);
      return text;
    } catch (error) {
      lastError = error;
      if (attempt < RETRIES && (error.name === 'AbortError' || error instanceof TypeError)) {
        await sleep(Math.min(1000 * 2 ** attempt, 10000));
        continue;
      }
      break;
    } finally { clearTimeout(timer); }
  }
  throw lastError || new Error('Request gagal');
}

function parseCard($card) {
  const $a = $card.find('.bsx a[href], a.tip[href]').first();
  const url = absolute($a.attr('href'));
  if (!url || !isDongHiveUrl(url)) return null;
  const image = $card.find('img').first();
  const title = ($a.attr('title') || $card.find('.tt h2, h2').first().text() || '').trim();
  return {
    title: title || null,
    url,
    slug: url.replace(/\/$/, '').split('/').pop(),
    poster: absolute(image.attr('data-src') || image.attr('data-lazy-src') || image.attr('src')),
    type: ($card.find('.typez').first().text() || $card.find('.epx').first().text() || '').trim().toLowerCase() || null,
    sub: $card.find('.sb').first().text().trim() || null,
    hot: $card.find('.hotbadge').length > 0
  };
}

async function scrapeListPage(url) {
  if (!isDongHiveUrl(url)) throw new Error('URL katalog bukan domain DongHive');
  const $ = cheerio.load(await request(url));
  const items = [];
  $('article.bs').each((_, el) => { const item = parseCard($(el)); if (item) items.push(item); });
  const candidates = $('a[href*="/page/"]').toArray().map(el => absolute($(el).attr('href'))).filter(Boolean);
  const next = candidates.find(link => /\/page\/\d+\/?/.test(new URL(link).pathname)) || null;
  return { items, next };
}

export async function scrapeCatalog({ pages = 2, limit = 40 } = {}) {
  const seen = new Set(); const output = [];
  let url = `${BASE}/anime/?status=&type=&order=update`;
  for (let page = 0; page < Math.max(1, Math.min(Number(pages) || 2, 5)) && url; page++) {
    const parsed = await scrapeListPage(url);
    for (const item of parsed.items) {
      if (!seen.has(item.url)) { seen.add(item.url); output.push(item); }
      if (output.length >= Math.max(1, Math.min(Number(limit) || 40, 100))) return output;
    }
    url = parsed.next;
  }
  return output;
}

export async function scrapeSeries(url) {
  if (!isDongHiveUrl(url)) throw new Error('URL series bukan domain DongHive');
  const $ = cheerio.load(await request(url));
  const title = $('h1').first().text().trim() || $('meta[property="og:title"]').attr('content')?.replace(/\s*-\s*Donghive$/, '') || '';
  const poster = $('meta[property="og:image"]').attr('content') || $('.imgseries img, .seriesinfo img, .infox img').first().attr('src') || null;
  const synopsis = ($('.entry-content, .synopsis, .desc').first().text() || $('meta[property="og:description"]').attr('content') || '').trim();
  const genres = [];
  $('a[rel="tag"][href*="/genres/"]').each((_, el) => { const genre = $(el).text().trim(); if (genre) genres.push(genre); });
  const statusText = $('.spe').text();
  const status = statusText.match(/Status:\s*([^\t\n]+)/i)?.[1]?.trim() || null;
  const network = $('a[href*="/network/"]').first().text().trim() || null;
  const episodes = [];
  $('li[data-index] a[href]').each((_, el) => {
    const href = absolute($(el).attr('href'), url);
    if (!href || !isDongHiveUrl(href)) return;
    const numText = $(el).find('.epl-num').text().trim();
    const numMatch = numText.match(/\d+(?:\.\d+)?/);
    episodes.push({ number: numMatch ? Number(numMatch[0]) : null, title: $(el).find('.epl-title').text().trim() || null, url: href, date: $(el).find('.epl-date').text().trim() || null });
  });
  return { title, url, poster: absolute(poster, url), synopsis, genres: [...new Set(genres)], status, network, totalEpisodes: episodes.length, episodes };
}

export async function scrapeEpisode(url) {
  if (!isDongHiveUrl(url)) throw new Error('URL episode bukan domain DongHive');
  const $ = cheerio.load(await request(url));
  const title = $('h1.entry-title').first().text().trim() || $('title').text().trim();
  const rawIframe = $('#pembed iframe, .player-embed iframe, .video-content iframe').first().attr('src') || null;
  const embedUrl = rawIframe ? absolute(rawIframe.replace(/&amp;/g, '&'), url) : null;
  const videoId = embedUrl?.match(/[?&]video=([A-Za-z0-9_-]+)/)?.[1] || embedUrl?.match(/dailymotion\.com\/(?:embed\/)?video\/([A-Za-z0-9]+)/)?.[1] || null;
  const slug = new URL(url).pathname.replace(/\/$/, '').split('/').pop() || '';
  const seriesSlug = slug.match(/^(.+?)-(?:episode|movie|chapter|ova|special|preview)-/i)?.[1] || null;
  return { title, url, seriesUrl: seriesSlug ? `${BASE}/${seriesSlug}/` : null, embedUrl, videoId, provider: videoId ? 'Dailymotion' : (embedUrl ? 'External embed' : null) };
}

export { isDongHiveUrl };
