import express from 'express';
import { scrapeCatalog, scrapeSeries, scrapeEpisode, isDongHiveUrl } from './scraper.js';

const app = express();
const PORT = Number(process.env.PORT || 8787);
app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));
app.get('/health', (_req, res) => res.json({ ok: true, service: 'KANASHI-Flix DongHive API' }));

app.get('/api/catalog', async (req, res) => {
  try {
    const pages = Math.min(Math.max(parseInt(req.query.pages || '2', 10) || 2, 1), 5);
    const limit = Math.min(Math.max(parseInt(req.query.limit || '40', 10) || 40, 1), 100);
    const includeDetails = req.query.details === '1';
    const items = await scrapeCatalog({ pages, limit });
    if (!includeDetails) return res.json({ source: 'DongHive', fetchedAt: new Date().toISOString(), total: items.length, items });

    // Enrichment dibatasi agar backend tidak membebani situs sumber.
    const enriched = [];
    // Batasi concurrency agar katalog lebih cepat tanpa membuat lonjakan request.
    for (let start = 0; start < items.length; start += 4) {
      const batch = items.slice(start, start + 4);
      const results = await Promise.all(batch.map(async item => {
        try {
          const series = await scrapeSeries(item.url);
          return { ...item, ...series, poster: series.poster || item.poster, totalEpisodes: series.totalEpisodes || 0 };
        } catch {
          return { ...item, synopsis: '', genres: [], status: null, totalEpisodes: 0, episodes: [] };
        }
      }));
      enriched.push(...results);
    }
    res.json({ source: 'DongHive', fetchedAt: new Date().toISOString(), total: enriched.length, items: enriched });
  } catch (error) {
    res.status(502).json({ error: 'Gagal mengambil katalog DongHive', detail: error.message });
  }
});

app.get('/api/series', async (req, res) => {
  try {
    const url = String(req.query.url || '');
    if (!isDongHiveUrl(url)) return res.status(400).json({ error: 'Parameter url harus berupa URL HTTPS DongHive.' });
    res.json(await scrapeSeries(url));
  } catch (error) { res.status(502).json({ error: 'Gagal mengambil detail series', detail: error.message }); }
});

app.get('/api/episode', async (req, res) => {
  try {
    const url = String(req.query.url || '');
    if (!isDongHiveUrl(url)) return res.status(400).json({ error: 'Parameter url harus berupa URL HTTPS DongHive.' });
    // Kembalikan halaman episode dan embed resmi yang tercantum pada halaman sumber.
    // Pemutaran memakai player embed; tidak menyalin atau menyimpan URL manifest bertanda tangan.
    res.json(await scrapeEpisode(url));
  } catch (error) { res.status(502).json({ error: 'Gagal mengambil detail episode', detail: error.message }); }
});

app.listen(PORT, '0.0.0.0', () => console.log(`KANASHI-Flix DongHive API berjalan pada port ${PORT}`));
