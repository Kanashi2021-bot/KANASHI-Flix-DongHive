# Panduan KANASHI-Flix dari HP

Paket ini menyiapkan dua hal: backend DongHive untuk di-hosting dan workflow GitHub Actions untuk mencoba membangun APK debug secara online. Ini belum berarti aplikasi sudah live atau APK sudah berhasil dibangun; URL backend harus diisi dan proses build cloud harus dijalankan.

## A. Hosting backend DongHive
1. Buat akun GitHub dan buat repository baru, misalnya `KANASHI-Flix`.
2. Unggah seluruh isi folder proyek `kanashi_flix` ke repository tersebut. Pastikan `render.yaml` berada di root repository dan folder `donghive-backend` ikut terunggah.
3. Buat akun di Render dan pilih **New + → Blueprint**.
4. Hubungkan repository GitHub tadi. Render akan membaca `render.yaml`; lanjutkan pembuatan layanan.
5. Setelah deploy selesai, buka layanan backend dan salin URL HTTPS yang diberikan Render.
6. Tes URL itu dengan menambahkan `/health`. Hasil yang diharapkan berupa JSON dengan `"ok": true`.

Catatan: layanan gratis dapat tidur saat tidak dipakai dan respons pertama bisa lambat. Scraper tergantung struktur serta ketersediaan DongHive.

## B. Menghubungkan aplikasi ke backend
1. Di GitHub, buka `app/src/main/java/com/example/data/DongHiveApi.kt`.
2. Tekan ikon pensil untuk mengedit.
3. Ganti nilai `BASE_URL` yang masih berisi placeholder dengan URL HTTPS Render Anda, tanpa garis miring di akhir. Contoh bentuknya: `https://nama-layanan.onrender.com`.
4. Simpan perubahan dengan **Commit changes**.

## C. Mencoba membuat APK online
1. Buka tab **Actions** pada repository GitHub.
2. Pilih workflow **Build Android APK**.
3. Tekan **Run workflow** jika belum berjalan otomatis setelah commit.
4. Tunggu sampai job selesai. Jika gagal, buka job tersebut dan lihat bagian merah/error; proyek ini belum diuji build pada lingkungan Android SDK di sini.
5. Jika berhasil, buka ringkasan workflow, cari bagian **Artifacts**, lalu unduh `KANASHI-Flix-debug-apk`. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.
6. Pindahkan APK ke HP Android dan instal. Android mungkin meminta izin instal aplikasi dari sumber tersebut.

## Catatan penting
- APK debug untuk uji coba, bukan rilis Play Store.
- Login Google membutuhkan konfigurasi Firebase/Google OAuth yang cocok dengan application ID, SHA-1/SHA-256, dan file konfigurasi proyek. Menambahkan DongHive tidak otomatis memperbaiki login Google.
- Pemutaran memakai halaman episode/embed yang tersedia pada sumber; tidak dijamin semua episode bisa diputar di WebView.
- Gunakan konten yang memang boleh diakses dan disematkan. Integrasi ini tidak melewati DRM, login, geo-block, atau pembatasan sumber.
